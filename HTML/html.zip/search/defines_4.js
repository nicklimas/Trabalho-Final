var searchData=
[
  ['given_1578',['GIVEN',['../doctest_8h.html#a6fdd23caff3293146ba6929b2d77465a',1,'doctest.h']]]
];
