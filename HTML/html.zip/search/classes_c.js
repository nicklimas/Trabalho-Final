var searchData=
[
  ['querydata_848',['QueryData',['../structdoctest_1_1QueryData.html',1,'doctest']]]
];
