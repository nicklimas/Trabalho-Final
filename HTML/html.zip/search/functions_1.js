var searchData=
[
  ['biblioteca_930',['Biblioteca',['../classBiblioteca.html#a5e12ea4e7a4edb14d210a41708fc1c10',1,'Biblioteca']]],
  ['binary_5fassert_931',['binary_assert',['../structdoctest_1_1detail_1_1ResultBuilder.html#aa920a0617a26939d7adcd1ba2dec0e85',1,'doctest::detail::ResultBuilder::binary_assert()'],['../namespacedoctest_1_1detail.html#a1e295c708d2de0e47ac89c1632211159',1,'doctest::detail::binary_assert()']]]
];
