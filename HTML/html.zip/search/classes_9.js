var searchData=
[
  ['messagebuilder_844',['MessageBuilder',['../structdoctest_1_1detail_1_1MessageBuilder.html',1,'doctest::detail']]],
  ['messagedata_845',['MessageData',['../structdoctest_1_1MessageData.html',1,'doctest']]]
];
