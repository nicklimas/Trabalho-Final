var searchData=
[
  ['categorias_2etxt_893',['categorias.txt',['../categorias_8txt.html',1,'']]]
];
