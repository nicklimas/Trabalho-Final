var searchData=
[
  ['value_763',['value',['../structdoctest_1_1detail_1_1types_1_1true__type.html#a5ad232af56ff87690d552f77e0413f02',1,'doctest::detail::types::true_type::value()'],['../structdoctest_1_1detail_1_1types_1_1false__type.html#a8580f67f4b223b10e49d93b959767f6d',1,'doctest::detail::types::false_type::value()'],['../structdoctest_1_1detail_1_1types_1_1is__enum.html#a2ac322024808b91cda5ce1a42691ee07',1,'doctest::detail::types::is_enum::value()'],['../structdoctest_1_1IsNaN.html#a6a490d3d5f5561bcf019fefc88291475',1,'doctest::IsNaN::value()']]],
  ['version_764',['version',['../structdoctest_1_1ContextOptions.html#a08931527a9e5e634e64a336e5493a7c1',1,'doctest::ContextOptions']]],
  ['view_5fdados_765',['view_dados',['../classLivro.html#af7915ca5afe68d9aaea54e56c21c3330',1,'Livro::view_dados()'],['../classAdmin.html#ae20e462a30b6e7ec17ef33ded440c708',1,'Admin::view_dados()'],['../classPessoa.html#aea1cebc9b03cc6953c1efedfe4f7e530',1,'Pessoa::view_dados()'],['../classUsuario.html#ad44526eff833ef103f15b6bd574c1130',1,'Usuario::view_dados()']]],
  ['view_5flivros_766',['view_livros',['../classUsuario.html#a91881d23be7ca3f0296988399185f30d',1,'Usuario']]]
];
