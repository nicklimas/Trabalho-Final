var searchData=
[
  ['view_5fdados_1079',['view_dados',['../classLivro.html#af7915ca5afe68d9aaea54e56c21c3330',1,'Livro::view_dados()'],['../classAdmin.html#ae20e462a30b6e7ec17ef33ded440c708',1,'Admin::view_dados()'],['../classPessoa.html#aea1cebc9b03cc6953c1efedfe4f7e530',1,'Pessoa::view_dados()'],['../classUsuario.html#ad44526eff833ef103f15b6bd574c1130',1,'Usuario::view_dados()']]],
  ['view_5flivros_1080',['view_livros',['../classUsuario.html#a91881d23be7ca3f0296988399185f30d',1,'Usuario']]]
];
