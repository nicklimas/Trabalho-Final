var searchData=
[
  ['what_1081',['what',['../classErroaAbrirArquivo.html#a2bd43a8cd0a329d8cbf1f4ad1b83abba',1,'ErroaAbrirArquivo::what()'],['../classOperacaoInterrompida.html#a25366aa78858e3ee4bb04d6bfe502721',1,'OperacaoInterrompida::what()']]]
];
