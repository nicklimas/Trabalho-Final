var searchData=
[
  ['adciona_5flinha_918',['adciona_linha',['../classArquivos.html#afe564e3e99d3e77043a56f69deef9e3f',1,'Arquivos']]],
  ['adciona_5flivro_919',['adciona_livro',['../classBiblioteca.html#af32cbb7d19d0df44a9788df5a29d24f0',1,'Biblioteca']]],
  ['add_5fautor_920',['add_autor',['../classBiblioteca.html#ac73eaa87ed1eec6d6713fb0804894ec9',1,'Biblioteca']]],
  ['add_5fcategoria_921',['add_categoria',['../classBiblioteca.html#a92d87ad06cbef647aee17b3a54639467',1,'Biblioteca']]],
  ['addfilter_922',['addFilter',['../classdoctest_1_1Context.html#a60ad57a46c19db2b142468c3acac448a',1,'doctest::Context']]],
  ['admin_923',['Admin',['../classAdmin.html#a451085579578febffaccdcd91bc06443',1,'Admin']]],
  ['applycommandline_924',['applyCommandLine',['../classdoctest_1_1Context.html#ad55229220bf9ca74e6e0c6323bf672e1',1,'doctest::Context']]],
  ['approx_925',['Approx',['../structdoctest_1_1Approx.html#a86f0d1b44c1cf095697f23ccdab00802',1,'doctest::Approx']]],
  ['assertdata_926',['AssertData',['../structdoctest_1_1AssertData.html#ae1f9906888c2dd06b6291ab196f5074e',1,'doctest::AssertData']]],
  ['assertstring_927',['assertString',['../namespacedoctest.html#a6bf4f7c2a8d412505384d13abbf878e9',1,'doctest']]],
  ['atualiza_5farquivo_5flivros_928',['atualiza_arquivo_livros',['../classSistema.html#af162890975280452c2468757c8c5ebdf',1,'Sistema']]],
  ['atualiza_5fhistorico_929',['atualiza_historico',['../classSistema.html#ac2745643a4ce3d138569c922b9055089',1,'Sistema']]]
];
