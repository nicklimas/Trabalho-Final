var searchData=
[
  ['yellow_1297',['Yellow',['../namespacedoctest_1_1Color.html#a32e9eaf6013139846e848af6e6cf2b92a5da6111e5be1d7b01de0ee571cc1bc76',1,'doctest::Color']]]
];
