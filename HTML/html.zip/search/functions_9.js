var searchData=
[
  ['main_1005',['main',['../main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cpp']]],
  ['makecontextscope_1006',['MakeContextScope',['../namespacedoctest_1_1detail.html#a193493f40330f096b9e1b78557a832a3',1,'doctest::detail']]],
  ['messagebuilder_1007',['MessageBuilder',['../structdoctest_1_1detail_1_1MessageBuilder.html#a93cb6f180968d38cb0f18b08ec6c9000',1,'doctest::detail::MessageBuilder::MessageBuilder(const char *file, int line, assertType::Enum severity)'],['../structdoctest_1_1detail_1_1MessageBuilder.html#ae40185a1fbaf07becd0bd077806f0358',1,'doctest::detail::MessageBuilder::MessageBuilder(const MessageBuilder &amp;)=delete'],['../structdoctest_1_1detail_1_1MessageBuilder.html#a1b5690556dd0fc3ac24c998f49b96147',1,'doctest::detail::MessageBuilder::MessageBuilder(MessageBuilder &amp;&amp;)=delete']]],
  ['muda_5fstatus_1008',['muda_status',['../classLivro.html#afdcc58cdbce502f36b992e5b8b6523e2',1,'Livro']]]
];
