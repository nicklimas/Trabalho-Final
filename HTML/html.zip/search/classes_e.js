var searchData=
[
  ['sistema_857',['Sistema',['../classSistema.html',1,'']]],
  ['string_858',['String',['../classdoctest_1_1String.html',1,'doctest']]],
  ['stringcontains_859',['StringContains',['../classdoctest_1_1AssertData_1_1StringContains.html',1,'doctest::AssertData']]],
  ['stringmaker_860',['StringMaker',['../structdoctest_1_1StringMaker.html',1,'doctest']]],
  ['stringmakerbase_861',['StringMakerBase',['../structdoctest_1_1detail_1_1StringMakerBase.html',1,'doctest::detail']]],
  ['stringmakerbase_3c_20detail_3a_3ahas_5finsertion_5foperator_3c_20t_20_3e_3a_3avalue_7c_7cdetail_3a_3atypes_3a_3ais_5fpointer_3c_20t_20_3e_3a_3avalue_7c_7cdetail_3a_3atypes_3a_3ais_5farray_3c_20t_20_3e_3a_3avalue_20_3e_862',['StringMakerBase&lt; detail::has_insertion_operator&lt; T &gt;::value||detail::types::is_pointer&lt; T &gt;::value||detail::types::is_array&lt; T &gt;::value &gt;',['../structdoctest_1_1detail_1_1StringMakerBase.html',1,'doctest::detail']]],
  ['stringmakerbase_3c_20true_20_3e_863',['StringMakerBase&lt; true &gt;',['../structdoctest_1_1detail_1_1StringMakerBase_3_01true_01_4.html',1,'doctest::detail']]],
  ['subcase_864',['Subcase',['../structdoctest_1_1detail_1_1Subcase.html',1,'doctest::detail']]],
  ['subcasesignature_865',['SubcaseSignature',['../structdoctest_1_1SubcaseSignature.html',1,'doctest']]]
];
