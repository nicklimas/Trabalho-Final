var searchData=
[
  ['react_1029',['react',['../structdoctest_1_1detail_1_1ResultBuilder.html#a03686f862471728c2980d72e02980213',1,'doctest::detail::ResultBuilder::react()'],['../structdoctest_1_1detail_1_1MessageBuilder.html#a3a65c5e39a0c04ae8e2a7c34997a2e4d',1,'doctest::detail::MessageBuilder::react()']]],
  ['registerexceptiontranslator_1030',['registerExceptionTranslator',['../namespacedoctest.html#a8e23e6bb4c6982688652060dbe41385d',1,'doctest']]],
  ['registerexceptiontranslatorimpl_1031',['registerExceptionTranslatorImpl',['../namespacedoctest_1_1detail.html#a3887426da16e0d12e6f0e270a767a6a5',1,'doctest::detail']]],
  ['registerreporter_1032',['registerReporter',['../namespacedoctest.html#a9e878a811f7bf0a615b3a39de3004673',1,'doctest']]],
  ['registerreporterimpl_1033',['registerReporterImpl',['../namespacedoctest_1_1detail.html#a828e011bb6028ab94eb14a3c7d8bd2c4',1,'doctest::detail']]],
  ['regtest_1034',['regTest',['../namespacedoctest_1_1detail.html#a00f99edefb8490a8e2602d58c96431f4',1,'doctest::detail']]],
  ['remove_5flivro_1035',['remove_livro',['../classBiblioteca.html#a43d4917b903bbb0f03504d5e65d8a564',1,'Biblioteca::remove_livro()'],['../classSistema.html#a7107b87a6c800b27ddf5a970a80b4db6',1,'Sistema::remove_livro()']]],
  ['report_5fquery_1036',['report_query',['../structdoctest_1_1IReporter.html#ae7e30d1c2cd332094c66d39bf3a85e52',1,'doctest::IReporter']]],
  ['reportercreator_1037',['reporterCreator',['../namespacedoctest_1_1detail.html#a575cd92f018bfe3c702432a2144ebaca',1,'doctest::detail']]],
  ['result_1038',['Result',['../structdoctest_1_1detail_1_1Result.html#ae38382da1a2d2f8e33aebc7da15febc9',1,'doctest::detail::Result::Result()=default'],['../structdoctest_1_1detail_1_1Result.html#ae4d2e8633aedaffa31f5c8b8530f522c',1,'doctest::detail::Result::Result(bool passed, const String &amp;decomposition=String())']]],
  ['resultbuilder_1039',['ResultBuilder',['../structdoctest_1_1detail_1_1ResultBuilder.html#a135e00690002d376f3d050700a635680',1,'doctest::detail::ResultBuilder::ResultBuilder(assertType::Enum at, const char *file, int line, const char *expr, const char *exception_type=&quot;&quot;, const String &amp;exception_string=&quot;&quot;)'],['../structdoctest_1_1detail_1_1ResultBuilder.html#ab55660e3aaa5d8fccbe19360f65bb1f3',1,'doctest::detail::ResultBuilder::ResultBuilder(assertType::Enum at, const char *file, int line, const char *expr, const char *exception_type, const Contains &amp;exception_string)']]],
  ['rfind_1040',['rfind',['../classdoctest_1_1String.html#a6e22f4f3820de5ffdf82e0acc6646759',1,'doctest::String']]],
  ['run_1041',['run',['../classdoctest_1_1Context.html#a8059b137ef41cbe6c5d8160806a3cc63',1,'doctest::Context']]]
];
