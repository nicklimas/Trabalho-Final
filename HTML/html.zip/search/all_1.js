var searchData=
[
  ['biblioteca_27',['Biblioteca',['../classBiblioteca.html',1,'Biblioteca'],['../classBiblioteca.html#a5e12ea4e7a4edb14d210a41708fc1c10',1,'Biblioteca::Biblioteca()']]],
  ['biblioteca_2ecpp_28',['biblioteca.cpp',['../biblioteca_8cpp.html',1,'']]],
  ['biblioteca_2ehpp_29',['biblioteca.hpp',['../biblioteca_8hpp.html',1,'']]],
  ['binary_5fassert_30',['binary_assert',['../structdoctest_1_1detail_1_1ResultBuilder.html#aa920a0617a26939d7adcd1ba2dec0e85',1,'doctest::detail::ResultBuilder::binary_assert()'],['../namespacedoctest_1_1detail.html#a1e295c708d2de0e47ac89c1632211159',1,'doctest::detail::binary_assert()']]],
  ['binary_5fname_31',['binary_name',['../structdoctest_1_1ContextOptions.html#a0590006b4d10296c9a697e32ff886f74',1,'doctest::ContextOptions']]],
  ['blue_32',['Blue',['../namespacedoctest_1_1Color.html#a32e9eaf6013139846e848af6e6cf2b92aada3ad8958b1319450cc20f3f8e5e2d6',1,'doctest::Color']]],
  ['bright_33',['Bright',['../namespacedoctest_1_1Color.html#a32e9eaf6013139846e848af6e6cf2b92a7659647d16a78c607f9bafaa207b9e07',1,'doctest::Color']]],
  ['brightgreen_34',['BrightGreen',['../namespacedoctest_1_1Color.html#a32e9eaf6013139846e848af6e6cf2b92a016090b96620a42a63dadf0265977664',1,'doctest::Color']]],
  ['brightred_35',['BrightRed',['../namespacedoctest_1_1Color.html#a32e9eaf6013139846e848af6e6cf2b92a236dfdbcd49d10dbf1a31f9e2947a671',1,'doctest::Color']]],
  ['brightwhite_36',['BrightWhite',['../namespacedoctest_1_1Color.html#a32e9eaf6013139846e848af6e6cf2b92a4f80853796b4875d61ff5e4ad138492e',1,'doctest::Color']]],
  ['buf_37',['buf',['../classdoctest_1_1String.html#a7e031ced488588936a540eba26facf67',1,'doctest::String']]]
];
