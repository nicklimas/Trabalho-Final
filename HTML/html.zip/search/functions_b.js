var searchData=
[
  ['pega_5flivro_1027',['pega_livro',['../classSistema.html#a9987765d5f67e230ddd6f26cae6d7a55',1,'Sistema::pega_livro()'],['../classUsuario.html#a3384060f13f28a34d015d70dd267e71d',1,'Usuario::pega_livro()']]],
  ['pessoa_1028',['Pessoa',['../classPessoa.html#a22563fe1f53faa9b1d8d10d28ae0c650',1,'Pessoa::Pessoa()'],['../classPessoa.html#a5971db7e6c2589e9b502fa7d07d80b66',1,'Pessoa::Pessoa(std::string email, std::string senha)'],['../classPessoa.html#a61273e728a6e3befe2ef61b4bb4e6c83',1,'Pessoa::Pessoa(std::string nome, std::string email, std::string senha)']]]
];
